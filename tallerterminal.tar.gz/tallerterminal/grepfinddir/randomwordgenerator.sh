#!/bin/bash

for i in {1..1000};
do
RANDOM_WORD=$(shuf -n 1 /usr/share/dict/words)
echo "$RANDOM_WORD" >> "wordsearch.txt"
done
